ulimit -n 65535
cd /home/mo/HttpSvr/bin/
nohup ./HttpSvr > /dev/null 2>&1 &