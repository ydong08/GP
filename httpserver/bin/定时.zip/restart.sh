cd /home/mo/HttpSvr/bin/
sh ./stop.sh
sleep 3
sh ./start.sh